"use strict";

let form = document.getElementById("form1");

window.onload = function () {
  form.password.value = "monkey";
  form.city.value = "New York";
  form.comment.value = "";

  let nameFromLocalStorageVal = localStorage.getItem("fnameOfUser");

  
  if (nameFromLocalStorageVal) {
    
    document.getElementById("fname").value = nameFromLocalStorageVal;
  }
};

form.addEventListener("change", fName);

function fName() {
 
  const name = document.getElementById("fname");

 
  localStorage.setItem("fnameOfUser", name.value);

  let nameval = name.value;
  if (nameval.length > 5) {
    name.style.backgroundColor = "lightgreen";
  } else {
    name.style.backgroundColor = "white";
  }
}


document.getElementById("show").addEventListener("click", passwordShow);

function passwordShow() {
  const password = document.getElementById("password");

  if (password.type === "password") {
    password.type = "text";
    document.getElementById("show").innerHTML = "hide";
  } else {
    password.type = "password";
    document.getElementById("show").innerHTML = "show";
  }
}


document.getElementById("cbox").addEventListener("click", checkEnable);

function checkEnable() {
  const cboxx = document.getElementById("cbox");

  if (cboxx.checked == true) {
    document.getElementById("submit").disabled = false;
  } else {
    document.getElementById("submit").disabled = true;
  }
}


form.addEventListener("submit", submitFormNow);

function submitFormNow(e) {
  
  let selectedFoodVal = document.querySelector('input[name="food"]:checked').value;

  let textAreaVal = document.getElementById("comment").value;

  
  if (selectedFoodVal != 2) {
    alert("Apple must be selected");
  
    e.preventDefault();
  }

  
  if (textAreaVal === "") {
    alert("Comments must be entered");
    
    e.preventDefault();
  }
}
